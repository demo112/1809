from django.db import models
from django.contrib.auth.models import AbstractUser
SEX_CHOICES = {
    (0,'男'),
    (1,'女'),
}

ROLE_CHOICES = {
    (0,'买'),
    (1,'卖'),
}

BANK_CHOICES = {
    (0,'中国工商银行'),
    (1,'中国建设银行'),
    (2,'中国农业银行'),
    (3,'招商银行'),
    (4,'我的银行'),
}

BANK_STATUS = {
    (0,'冻结'),
    (1,'开通'),
    (2,'待激活'),
}

# from django.contrib.auth.models import AbstractUser
# Create your models here.
class UserInfo(AbstractUser):
    realname = models.CharField('真实姓名', max_length=50, null=False)
    cellphone = models.CharField('手机号', max_length=11, null=False)
    identity = models.CharField('身份证号', max_length=18, null=False)
    sex = models.IntegerField(verbose_name='性别', choices=SEX_CHOICES, default=0)
    role = models.IntegerField(verbose_name='角色', choices=ROLE_CHOICES, default=0)
    isActive = models.BooleanField(verbose_name='是否激活',default=False)
    isBan = models.BooleanField(verbose_name='是否禁用', default=False)
    isDelete = models.BooleanField(verbose_name='是否删除', default=False)

    def __str__(self):
        return self.username


# class UserInfo(models.Model):
#     username = models.CharField('用户名', max_length=50, null=False)
#     password = models.CharField('密码', max_length=200, null=False)
#     realname = models.CharField('真实姓名', max_length=50, null=False)
#     address = models.CharField('地址', max_length=200, null=False)
#     email = models.EmailField('邮箱')
#     cellphone = models.CharField('手机号', max_length=11, null=False)
#     identity = models.CharField('身份证号', max_length=18, null=False)
#     sex = models.IntegerField(verbose_name='性别', choices=SEX_CHOICES, default=0)
#     role = models.IntegerField(verbose_name='角色', choices=ROLE_CHOICES, default=0)
#     isActive = models.BooleanField(verbose_name='是否激活',default=False)
#     isBan = models.BooleanField(verbose_name='是否禁用', default=False)
#     isDelete = models.BooleanField(verbose_name='是否删除', default=False)
#
#     def __str__(self):
#         return self.username
#
#
class BankInfo(models.Model):
    user = models.ForeignKey(UserInfo)
    bank = models.IntegerField(verbose_name='开户行', choices=BANK_CHOICES, default=0)
    bankNo = models.CharField('银行卡号', max_length=50, null=False)
    status = models.IntegerField(verbose_name='状态', choices=BANK_STATUS, default=0)
    bankphone = models.CharField('银行手机号',max_length=11, null=False)

    def __str__(self):
        return self.user.username
#
#
# 流水表Cash
# id
# user 用户（Ｆ）
# order 订单（Ｆ）
# status 状态 Ic
# date 时间 Date
# price 金额 Decimal
#
#
# 最近浏览表Record
# id
# user 用户（Ｆ）
# car 汽车（Ｆ）
# date 时间 Datetime
# isDelete 是否删除 B
#
#
# 聊天记录表ChatList
# id
# userA 用户Ａ C
# userB 用户Ｂ C
# details 内容 Text
# date 时间 Date
# isDelete 是否删除 B
# status 状态 Ic
#
#
# 消息记录表Message
# id
# user 用户 (F)
# message 消息 C
# date 时间 Datetime
# isDelete 是否删除 B
# status 状态 Ic