from django.shortcuts import render, redirect
from .models import *
from django.contrib.auth.hashers import make_password, check_password
from django.http import HttpResponse
from django.contrib import auth
import json


# Create your views here.


def register_(request):
    # 判断提交请求方式
    # 获取前端数据
    # 查询用户姓名是否唯一
    #     是：判断两次密码是否一致
    #             是：
    #                 保存数据库
    #                 返回登录页
    #             否：返回注册页
    #     否：返回注册页
    if request.method == "POST":


        new_user = UserInfo()
        new_user.username = request.POST.get('username')

        # 获取前端数据列表，可用于多选
        new_user.sex = request.POST.getlist("sex")[0]
        olduser = UserInfo.objects.filter(username=new_user.username)
        if len(olduser)>0:
            return render(request,'uregister.html',{'message':"用户名已存在"})

        if request.POST.get("password") != request.POST.get("rpassword"):
            return render(request, 'uregister.html', {'message': "两次密码不一致"})
        new_user.password = make_password(request.POST.get("password"),None,'pbkdf2_sha1')
        # make_password(request.POST.get("password"),None,'pbkdf2_sha1')
        # make_password(request.POST.get("password"), None, 'pbkdf2_sha1')
        # make_password(request.POST.get("password"), 'abc', 'pbkdf2_sha1')
        # make_password('def', 'abc', 'pbkdf2_sha1')
        new_user.save()
        return render(request,'login.html')
        # return HttpResponse(json.dumps({"result":False, "data":"", "error":"两次密码不一致"}))


    if request.method == "GET":
        return render(request,'uregister.html')

def login_(request):
    # 判断请求方式post/get
    # 获取前端数据
    # 查询数据库判断用户名密码是否正确
    #     是：
    #         是否激活
    #             是：
    #                 存session cookie
    #                 返回首页
    #             否：返回登录页
    #     否：返回登录页
    if request.method == "POST":
        new_user = UserInfo()
        new_user.username = request.POST.get("username")
        new_user.password = request.POST.get("password")
        user = auth.authenticate(username=new_user.username, password=new_user.password)
        if user is not None and user.is_active:
            auth.login(request, user)
            if request.COOKIES.get('url'):
                url = request.COOKIES.get('url')
                res = redirect(url)
                res.delete_cookies('url')
                return res
            return render(request,"index.html")
        else:
            return render(request,"login.html",{"message":"用户名密码错误"})
    if request.method == "GET":
        return render(request,'login.html')


def logout_(request):
    auth.logout(request)
    return render(request,'login.html')











