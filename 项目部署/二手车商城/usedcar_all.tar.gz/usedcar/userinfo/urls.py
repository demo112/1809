
from django.conf.urls import url
from userinfo import views
from userinfo import viewsutil

urlpatterns = [
    url(r'uregister/',views.register_,name="uregister"),
    url(r'^ulogin/',views.login_,name="ulogin"),
    url('verifycode',viewsutil.verifycode),
]
