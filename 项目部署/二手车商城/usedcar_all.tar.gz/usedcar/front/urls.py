
from django.conf.urls import url


urlpatterns = [

]
