from django.db import models
from userinfo.models import *

DEBT_CHOICES = {
    ('无','无债务'),
    ('有','待处理债务'),
}

FOR_EXAMINE = {
    (0,'已提交'),
    (1,'审核中'),
    (2,'审核失败'),
    (3,'审核成功'),
}


# Create your models here.
class Brand(models.Model):
    brand = models.CharField('品牌名',max_length=50,null=False)
    logo = models.ImageField(verbose_name='标志', upload_to='img/logo', default='brandlogo.png')
    isDelete = models.BooleanField(verbose_name='是否删除', default=False)

    def __str__(self):
        return self.brand


class CarInfo(models.Model):
    isDelete = models.BooleanField(verbose_name='是否删除', default=False)
    user = models.ForeignKey(UserInfo)
    brand = models.ForeignKey(Brand)
    ctitle = models.CharField('车辆名称', max_length=50, null=False)
    regist_date = models.DateField(verbose_name='上牌日期')
    engineNo = models.CharField('发动机号', max_length=50, null=False)
    mileage = models.IntegerField(verbose_name='公里数', default=0)
    maintenance_record = models.TextField(verbose_name='维修记录')
    price = models.DecimalField(verbose_name='期望售价', decimal_places=2, max_digits=10)
    extreactprice = models.DecimalField(verbose_name='成交价格', decimal_places=2, max_digits=10)
    newprice = models.DecimalField(verbose_name='新车价格', decimal_places=2, max_digits=10)
    picture = models.ImageField(verbose_name='图片', upload_to='img/car', default='normal.png')
    debt = models.CharField(verbose_name='债务', choices=DEBT_CHOICES, default='无',max_length=20)
    other = models.TextField(verbose_name='第三方评估')
    promise = models.TextField(verbose_name='卖家承诺')
    examine = models.IntegerField(verbose_name='审核进度', choices=FOR_EXAMINE, default=0)
    isPurchase = models.BooleanField(verbose_name='是否已售', default=False)

    def __str__(self):
        return self.user.username