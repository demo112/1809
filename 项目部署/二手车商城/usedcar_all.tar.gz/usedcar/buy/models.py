from django.db import models
from userinfo.models import *
from sale.models import *
# Create your models here.
class Cart(models.Model):
    user = models.ForeignKey(UserInfo)
    car = models.ForeignKey(CarInfo)
    price = models.DecimalField(verbose_name='价格', max_digits=10, decimal_places=2)

    def __str__(self):
        return self.user.username

class Order(models.Model):
    order_date = models.DateTimeField(verbose_name='交易时间', auto_now_add=True)
    price = models.DecimalField(verbose_name='交易价格', max_digits=10, decimal_places=2)
    orderNo = models.CharField('订单号',max_length=50,null=False)
    sale_user = models.ForeignKey(UserInfo, related_name='suser', on_delete=models.CASCADE)
    buy_user = models.ForeignKey(UserInfo, related_name='buser')

    def __str__(self):
        return self.orderNo

class Orderdetails(models.Model):
    order = models.ForeignKey(Order)
    brand = models.ForeignKey(Brand)
    ctitle = models.CharField('车辆名称', max_length=50, null=False)
    regist_date = models.DateField(verbose_name='上牌日期')
    engineNo = models.CharField('发动机号', max_length=50, null=False)
    mileage = models.IntegerField(verbose_name='公里数', default=0)
    maintenance_record = models.TextField(verbose_name='维修记录')
    price = models.DecimalField(verbose_name='期望售价', decimal_places=2, max_digits=10)
    extreactprice = models.DecimalField(verbose_name='成交价格', decimal_places=2, max_digits=10)
    newprice = models.DecimalField(verbose_name='新车价格', decimal_places=2, max_digits=10)
    picture = models.ImageField(verbose_name='图片', upload_to='img/car', default='normal.png')
    debt = models.CharField(verbose_name='债务', choices=DEBT_CHOICES, default='无', max_length=20)
    other = models.TextField(verbose_name='第三方评估')
    promise = models.TextField(verbose_name='卖家承诺')

    def __str__(self):
        return self.order.orderNo