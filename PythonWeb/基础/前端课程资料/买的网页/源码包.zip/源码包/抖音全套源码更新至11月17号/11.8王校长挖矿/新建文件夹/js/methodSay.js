/**
 * Created by Administrator on 2018/2/4.
 */
METHOD.SAY={
    pointAngleInfo:"获取两个点之间的角度",
    polarCoordinates:"通过一个点按照一定的方向位移",
    inRect:"判断点是否在矩形里面",
    bezierCurve:"贝塞尔曲线参考二阶贝塞尔曲线公式:(1 - t)^2 P0 + 2 t (1 - t) P1 + t^2 P2; 这符合一个线性变化",
    getRotatePoint:"获取矩形旋转过后的左顶点",
    defineEx:"类似defineProperty传入参数Obj,要监听的属性,初始值,改变值之前调用,改变值之后调用"
};