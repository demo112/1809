from django.conf.urls import url
from django.contrib import admin
from cartinfo import views

urlpatterns = [
    url('^$', views.cart_info, name='cart'),
    url(r'addcart', views.add_cart, name='addcart'),
]