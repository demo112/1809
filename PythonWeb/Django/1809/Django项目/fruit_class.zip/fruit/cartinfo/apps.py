from django.apps import AppConfig


class CartinfoConfig(AppConfig):
    name = 'cartinfo'
