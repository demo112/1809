from django.shortcuts import render, redirect
from .models import *
from django.core.exceptions import ObjectDoesNotExist
from django.db import DatabaseError
import logging
from django.contrib.auth.hashers import make_password, check_password

# Create your views here.

auth_check = 'MarceArhut'

def register_in(request):
    return render(request, 'register.html')


def register_(request):
    # 1.判断传递方式
    # 2.获取用户
    # 3.判断用户是否存在
    # 4.判断两次密码是否一致
    # 5.将用户注册(加密注册)
    # 6.返回
    if request.method == 'POST':
        # 申明用户类
        new_user = UserInfo()
        # 获取用户
        new_user.uname = request.POST.get('user_name')
        # 查询用户
        try:
            a = UserInfo.objects.filter(uname=new_user.uname)
            if a:
                # 若用户存在,返回注册页,提示用户名已经存在
                return render(request, 'register.html', {"message":"该用户名已经存在"})
        except ObjectDoesNotExist as e:
            logging.warning(e)
        if request.POST.get('pwd') != request.POST.get('cpwd'):
            return render(request, 'register.html', {'message': '两次输入的密码不一致'})
        new_user_pwd = make_password(request.POST.get('pwd'), auth_check, 'pbkdf2_sha1')
        # 参1: 加密的密码, 参2: 任意字符串(用于固定生成的字符串, 不能为空) 参3: 加密方式
        # 得到的是一串随机字符串, 并且每次生成都不一样
        # 如果你不想每次都生成不同的密文，可以把make_password的第二个函数给一个固定的字符串
        new_user.upassword = new_user_pwd
        new_user.email = request.POST.get('email')
        try:
            new_user.save()
        except DatabaseError as e:
            logging.warning(e)
        return render(request, 'login.html')


def signin(request):
    return render(request, 'login.html')


def login_(request):
    # 1.判断传递方式
    # 2.获取用户,密码
    # 3.判断用户是否注册
    # 4.判断密码是否正确
    # 5.存session
    if request.method == 'POST':
        user = UserInfo()
        user.uname = request.POST.get('user_name')
        user.upassword = request.POST.get('pwd')
        try:
            find_user = UserInfo.objects.filter(uname=user.uname)
            if len(find_user) <= 0:
                return render(request, 'login.html', {'message':"该用户未注册"})
            # 参1:明文, 参2:密文
            if not check_password(user.upassword, find_user[0].upassword):
                return render(request, 'login.html', {'message':'用户名或密码错误'})
        except ObjectDoesNotExist as e:
            logging.warning(e)
        request.session['user_id'] = find_user[0].id
        request.session['user_name'] = user.uname
        return redirect('/')


def login_out(request):
    try:
        if request.session['user_name']:
            del request.session['user_id']
            del request.session['user_name']
    except KeyError as e:
        logging.warning(e)
    return redirect('/')