from django.contrib import admin
from .models import CartInfo, Order
# Register your models here.
admin.site.register(CartInfo)
admin.site.register(Order)