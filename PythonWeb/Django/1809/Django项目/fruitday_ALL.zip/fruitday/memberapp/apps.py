from django.apps import AppConfig


class MemberappConfig(AppConfig):
    name = 'memberapp'
